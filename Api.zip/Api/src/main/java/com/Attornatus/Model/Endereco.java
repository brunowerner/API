package com.Attornatus.Model;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToOne;
import lombok.Data;

@Data
@Entity(name = "endereco") //Criação do modelo e da tabela endereco.
public class Endereco {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;
	
	@Column(name = "logradouro" ,nullable = false)
	private String logradouro;
	
	@Column(name = "cep", nullable = false)
	private String cep;
	
	@Column(name = "numero", nullable = false)
	private int numero;
	
	@Column(name = "cidade", nullable = false)
	private String cidade;
	
	@Column(name = "principal", nullable = false)
	private Boolean principal;
	
	
	// Relacionamento entre a tabela pessoa e a tabela endereco.
	@ManyToOne
	@JoinColumn(name = "pessoa_id", nullable = false)
	private Pessoa pessoa_id;
	
}
