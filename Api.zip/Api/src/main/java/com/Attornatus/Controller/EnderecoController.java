package com.Attornatus.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Attornatus.Model.Endereco;
import com.Attornatus.Repository.EnderecoRepository;

@RestController // Controller da entidade endereco.
@RequestMapping("/endereco") // Acessado pela url localhost:8090/endereco
public class EnderecoController {
	
	@Autowired
	private EnderecoRepository enderecoRepository;
	
	//Método para listar os endereços específicos de uma pessoa por dado um id, acesso pelo método GET.
	@GetMapping(path = "/{pessoa_id}")
	public List<Endereco> Listar(@PathVariable("pessoa_id") Integer pessoa_id){
		List<Endereco> enderecos = enderecoRepository.findAll();
		int linhas = enderecos.size();
		
		//Parte do código necessária para remover os ids que não são igual ao id passado como parâmetro.
		
		int removida = 0;
		for(int i = 0;i < linhas;i++) {
			Endereco e = enderecos.get(i - removida);
			if(e.getPessoa_id().getId() != pessoa_id) {
				enderecos.remove(i - removida);
				removida++;
			}
		}
		return enderecos;
	}
	
	@PostMapping //Método usado para criar um endereço.
	public void Criar(@RequestBody Endereco endereco) {
		if(endereco.getPrincipal() == false) { //Se o novo endereço estiver com o atributo principal igual a false apenas salva o endereço.
			enderecoRepository.save(endereco);
		}else {
			//Se o novo endereço estiver com o atributo principal igual a true.
			//Muda em todos os endereços com o id da pessoa o atributo principal como falso.
			//Ao final é salvo o novo endereço com o atributo principal igual a true. 
			
			List<Endereco> enderecos = enderecoRepository.findAll();
			int linhas = enderecos.size();
			
			for(int i = 0;i< linhas;i++) {
				Endereco e = enderecos.get(i);
				if(e.getPessoa_id().getId() == endereco.getPessoa_id().getId()) {
					e.setPrincipal(false);
					enderecoRepository.save(e);
				}
			}
			
			enderecoRepository.save(endereco);
			
		}
		
	}
	//Método usado para alterar o atributo principal para false ou true.
	//Os parâmetros necessários são o id da pessoa e do endereço pela a URL. E um corpo 
	@PostMapping(path = "/{pessoa_id}/{id}")
	public void Principal(@RequestBody Boolean principal, @PathVariable Integer pessoa_id, @PathVariable Integer id) {
		if(principal == false) { // Se a 
			Endereco endereco = enderecoRepository.findById(id).get();
			endereco.setPrincipal(principal);
			enderecoRepository.save(endereco);
		}else {
			
			List<Endereco> enderecos = enderecoRepository.findAll();
			int linhas = enderecos.size();
			
			// Percorre todos os enderecos, 
			// Se igual ao id da pessoa passado como parâmetro ira verifica: 
			// Se o id do endereço passado como parâmetro for igual, atribui o valor true ao campo principal,
			// Senão atribui o valor false ao campo principal.
			// Após as atribuições os endereços são salvos no repositório.
			
			for(int i = 0;i< linhas;i++) {
				Endereco e = enderecos.get(i);
				if(e.getPessoa_id().getId() == pessoa_id) {
					
					if(e.getId() == id) {
						e.setPrincipal(true);
						enderecoRepository.save(e);
					}else {
						e.setPrincipal(false);
						enderecoRepository.save(e);
					}
					
				}
			}
			
		}
		

		
	}
}
