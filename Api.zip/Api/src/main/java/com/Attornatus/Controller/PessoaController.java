package com.Attornatus.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.Attornatus.Model.Pessoa;
import com.Attornatus.Repository.PessoaRepository;

@RestController //Controller da entidade pessoa.
@RequestMapping("/pessoa") //Acessado pelo endereço localhost:8090/pessoa
public class PessoaController {

	@Autowired
	private PessoaRepository pessoaRepository;
	
	//Método usado para listar pessoas.
	@GetMapping
	public List<Pessoa> Listar(){
		return pessoaRepository.findAll();
	}
	
	//Método de consulta de pessoa por id.
	@GetMapping(path = "/{id}")
	public Pessoa Consulta(@PathVariable("id") Integer id) {
		return pessoaRepository.findById(id).get();
	}
	
	//Método usado para alterar uma pessoa.
	@PostMapping(path ="/{id}")
	public void Editar(@RequestBody Pessoa pessoa, @PathVariable("id") Integer id) {
		Pessoa p = pessoaRepository.findById(id).get();
		p.setNome(pessoa.getNome());
		p.setData_nascimento(pessoa.getData_nascimento());
		
		pessoaRepository.save(p);
	}
	
	//Método utilizado para criar uma pessoa
	@PostMapping
	public void Criar(@RequestBody Pessoa pessoa) {
		 pessoaRepository.save(pessoa);
		
	}
}
