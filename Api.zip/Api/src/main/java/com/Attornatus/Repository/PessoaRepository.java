package com.Attornatus.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.Attornatus.Model.Pessoa;

@Repository //Repositório da entidade pessoa.
public interface PessoaRepository extends JpaRepository<Pessoa, Integer> {

}
