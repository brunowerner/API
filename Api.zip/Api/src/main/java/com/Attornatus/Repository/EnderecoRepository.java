package com.Attornatus.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.Attornatus.Model.Endereco;

@Repository //Repositório da entidade endereco.
public interface EnderecoRepository extends JpaRepository<Endereco, Integer>{

}
