package com.Attornatus.Integracao;

import static org.junit.jupiter.api.Assertions.assertEquals;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.Attornatus.Controller.EnderecoController;
import com.Attornatus.Model.Endereco;
import com.Attornatus.Model.Pessoa;
import com.Attornatus.Repository.EnderecoRepository;
import com.Attornatus.Repository.PessoaRepository;

@SpringBootTest
public class EnderecoControllerTeste {

	@Autowired
	private PessoaRepository pessoaRepository;
	
	@Autowired
	private EnderecoRepository enderecoRepository;
	
	@Autowired
	private EnderecoController enderecoController;
	
	@Test
	void Listar() throws Exception {
		
		Date data_nascimento = Timestamp.valueOf("1910-05-14 00:00:00");	
		Pessoa pessoa = new Pessoa(1,"Bruno",data_nascimento);
		
		Date data_nascimento2 = Timestamp.valueOf("2010-07-12 00:00:00"); 
		Pessoa pessoa2 = new Pessoa(2,"Maria",data_nascimento2);
		
		Endereco endereco = new Endereco(1, "Rua das Maças", "851225-153", 984, "Curitiba", false, pessoa);		
		Endereco endereco2 = new Endereco(2, "Rua Marechal Floriano", "126518-814", 423, "São Paulo", false, pessoa2);
		Endereco endereco3 = new Endereco(3, "Rua Coronel Francisco", "156923-412", 423, "Rio de Janeiro", false, pessoa2);

		pessoaRepository.save(pessoa);
		pessoaRepository.save(pessoa2);
		enderecoRepository.save(endereco);
		enderecoRepository.save(endereco2);
		enderecoRepository.save(endereco3);
		
		ArrayList<Endereco> listaenderecos = new ArrayList<Endereco>();
		listaenderecos.add(endereco2);
		listaenderecos.add(endereco3);
		
		assertEquals(listaenderecos, enderecoController.Listar(2));
	}
	
	@Test
	void Criar() {
		Date data_nascimento = Timestamp.valueOf("1910-05-14 00:00:00");
		Pessoa pessoa = new Pessoa(1, "Bruno", data_nascimento);
		
		Date data_nascimento2 = Timestamp.valueOf("2010-07-12 00:00:00"); 
		Pessoa pessoa2 = new Pessoa(2, "Maria", data_nascimento2);
		
		Endereco endereco = new Endereco(1, "Rua das Maças", "851225-153", 984, "Curitiba", false, pessoa);
		Endereco endereco2 = new Endereco(2, "Rua Marechal Floriano", "126518-814", 423, "São Paulo", false, pessoa2);		
		Endereco endereco3 = new Endereco(3, "Rua Coronel Francisco", "156923-412", 423, "Rio de Janeiro", false, pessoa2);

		pessoaRepository.save(pessoa);
		pessoaRepository.save(pessoa2);
		
		enderecoController.Criar(endereco);
		
		assertEquals(endereco,enderecoRepository.findById(1).get());
		
		
	}
	
	
	@Test
	void Principal() {
		Date data_nascimento = Timestamp.valueOf("1910-05-14 00:00:00");
		Pessoa pessoa = new Pessoa(1, "Bruno", data_nascimento);
		
		Date data_nascimento2 = Timestamp.valueOf("2010-07-12 00:00:00"); 
		
		Pessoa pessoa2 = new Pessoa(2, "Maria", data_nascimento2);
		
		Endereco endereco = new Endereco(1, "Rua das Maças", "521225-153", 984, "Curitiba", false, pessoa);
		Endereco endereco2 = new Endereco(2, "Rua Marechal Floriano", "126518-814", 423, "São Paulo", false, pessoa2);
		Endereco endereco3 = new Endereco(3, "Rua Coronel Francisco", "156923-412", 423, "Rio de Janeiro", true, pessoa2);
		
		pessoaRepository.save(pessoa);
		pessoaRepository.save(pessoa2);
		enderecoRepository.save(endereco);
		enderecoRepository.save(endereco2);
		enderecoRepository.save(endereco3);
		
		enderecoController.Principal(true, 2, 2);
		
		endereco2.setPrincipal(true);
		endereco3.setPrincipal(false);
		
		ArrayList<Endereco> listaenderecos = new ArrayList<Endereco>();
		listaenderecos.add(endereco);
		listaenderecos.add(endereco2);
		listaenderecos.add(endereco3);
		
		assertEquals(listaenderecos, enderecoRepository.findAll());
		
	}

}
