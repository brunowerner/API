package com.Attornatus.Integracao;

import static org.junit.jupiter.api.Assertions.assertEquals;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import com.Attornatus.Controller.PessoaController;
import com.Attornatus.Model.Pessoa;
import com.Attornatus.Repository.PessoaRepository;


@SpringBootTest
public class PessoaControllerTeste {
	
	@Autowired
	private PessoaRepository pessoaRepository;
	
	@Autowired
	private PessoaController pessoaController;

	@Test
	void Listar() throws Exception {
		Date data_nascimento = Timestamp.valueOf("1910-05-14 00:00:00");
		Pessoa pessoa = new Pessoa(1,"Bruno",data_nascimento);
		
		Date data_nascimento2 = Timestamp.valueOf("2010-07-12 00:00:00"); 		
		Pessoa pessoa2 = new Pessoa(2,"Maria",data_nascimento2);

		ArrayList<Pessoa> listapessoa = new ArrayList<Pessoa>();
		listapessoa.add(pessoa);
		listapessoa.add(pessoa2);
		pessoaRepository.save(pessoa);
		pessoaRepository.save(pessoa2);
					
		assertEquals(listapessoa,pessoaController.Listar());
	}
	
	@Test
	void Consulta() throws Exception {
		Date data_nascimento = Timestamp.valueOf("1910-05-14 00:00:00");
		Pessoa pessoa = new Pessoa(1,"Bruno",data_nascimento);
		
		Date data_nascimento2 = Timestamp.valueOf("2010-07-12 00:00:00"); 		
		Pessoa pessoa2 = new Pessoa(2,"Maria",data_nascimento2);
		
		pessoaRepository.save(pessoa);
		pessoaRepository.save(pessoa2);
		
		assertEquals(pessoa,pessoaController.Consulta(1));
		
	}
	
	@Test
	void Editar() throws Exception {
		Date data_nascimento = Timestamp.valueOf("1910-05-14 00:00:00");
		Pessoa pessoa = new Pessoa(1,"Bruno",data_nascimento);
		
		Date data_nascimento2 = Timestamp.valueOf("2010-07-12 00:00:00"); 
		Pessoa pessoa2 = new Pessoa(2,"Maria",data_nascimento2);
		
		pessoaRepository.save(pessoa);
		pessoaRepository.save(pessoa2);
		
		data_nascimento = Timestamp.valueOf("2015-10-23 00:00:00");
		
		pessoa.setNome("Joel");
		pessoa.setData_nascimento(data_nascimento);
		
		pessoaController.Editar(pessoa, 1);
		
		assertEquals(pessoa,pessoaRepository.findById(1).get());
		
	}
	
	@Test
	void Criar() {
		Date data_nascimento = Timestamp.valueOf("1910-05-14 00:00:00");
		Pessoa pessoa = new Pessoa(1,"Bruno",data_nascimento);
		
		Date data_nascimento2 = Timestamp.valueOf("2010-07-12 00:00:00"); 		
		Pessoa pessoa2 = new Pessoa(2, "Maria", data_nascimento2);

		pessoaController.Criar(pessoa);
		
		assertEquals(pessoa , pessoaRepository.findById(1).get());
				
	}
	

}
