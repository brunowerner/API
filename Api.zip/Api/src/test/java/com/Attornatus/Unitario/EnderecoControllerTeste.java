package com.Attornatus.Unitario;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;

import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import com.Attornatus.Controller.EnderecoController;
import com.Attornatus.Model.Endereco;
import com.Attornatus.Model.Pessoa;
import com.Attornatus.Repository.EnderecoRepository;
import com.fasterxml.jackson.databind.ObjectMapper;

@WebMvcTest(controllers = EnderecoController.class)
class EnderecoControllerTeste {
	
	@Autowired
	private EnderecoController enderecoController;
	
	@Autowired
	private MockMvc mockMvc;
	
	@Autowired
	private ObjectMapper objectMapper;
	
	@MockBean
	private EnderecoRepository enderecoRepository;
	
	@Captor
	private ArgumentCaptor<Endereco> enderecoCaptor;

	@Test
	void Listar() throws Exception {
		
		Date data_nascimento = Timestamp.valueOf("1910-05-14 00:00:00");
		Pessoa pessoa = new Pessoa(1, "Bruno", data_nascimento);
		
		Date data_nascimento2 = Timestamp.valueOf("2010-07-12 00:00:00"); 
		Pessoa pessoa2 = new Pessoa(2, "Maria", data_nascimento2);

		Endereco endereco = new Endereco(1, "Rua das Maças", "851225-153", 984, "Curitiba", false, pessoa);		
		Endereco endereco2 = new Endereco(2, "Rua Marechal Floriano", "126518-814", 423, "São Paulo", false, pessoa2);
		Endereco endereco3 = new Endereco(3, "Rua Coronel Francisco", "156923-412", 423, "Rio de Janeiro", false, pessoa2);
		
		ArrayList<Endereco> listaenderecos = new ArrayList<Endereco>();
		listaenderecos.add(endereco);
		listaenderecos.add(endereco2);
		listaenderecos.add(endereco3);
		
		Mockito.when(enderecoRepository.findAll()).thenReturn(listaenderecos);
		
		ArrayList<Endereco> listaresultado = new ArrayList<Endereco>();
		listaresultado.add(endereco2);
		listaresultado.add(endereco3);
		
		mockMvc.perform(get("/endereco/{pessoa_id}", 2))
		.andExpect(status().isOk())
		.andExpect(content().json(objectMapper.writeValueAsString(listaresultado)));
		
	}
	
	@Test
	void Criar() throws Exception{
		Date data_nascimento = Timestamp.valueOf("1910-05-14 00:00:00");
		Pessoa pessoa = new Pessoa(1, "Bruno", data_nascimento);

		Date data_nascimento2 = Timestamp.valueOf("2010-07-12 00:00:00"); 
		Pessoa pessoa2 = new Pessoa(2, "Maria", data_nascimento2);
		
		Endereco endereco = new Endereco(1, "Rua das Maças", "851225-153", 984, "Curitiba", false, pessoa);
		Endereco endereco2 = new Endereco(2, "Rua Marechal Floriano", "126518-814", 423, "São Paulo", false, pessoa2);		
		Endereco endereco3 = new Endereco(3, "Rua Coronel Francisco", "156923-412", 423, "Rio de Janeiro", false, pessoa2);
		
		mockMvc.perform(post("/endereco")
				.contentType("application/json")
				.content(objectMapper.writeValueAsString(endereco)))
				.andExpect(status().isOk());
	}
	
	@Test
	void Principal() throws Exception {
		Date data_nascimento = Timestamp.valueOf("1910-05-14 00:00:00");
		Pessoa pessoa = new Pessoa(1, "Bruno", data_nascimento);
		
		Date data_nascimento2 = Timestamp.valueOf("2010-07-12 00:00:00"); 
		Pessoa pessoa2 = new Pessoa(2, "Maria", data_nascimento2);
		
		Endereco endereco = new Endereco(1, "Rua das Maças", "851225-153", 984, "Curitiba", false, pessoa);		
		Endereco endereco2 = new Endereco(2, "Rua Marechal Floriano", "126518-814", 423, "São Paulo", false, pessoa2);
		Endereco endereco3 = new Endereco(3, "Rua Coronel Francisco", "156923-412", 423, "Rio de Janeiro", true, pessoa2);
		
		Boolean principal = true;
		
		mockMvc.perform(post("/endereco/{pessoa_id}/{id}",2,2)
				.contentType("application/json")
				.content(objectMapper.writeValueAsString(principal)))
				.andExpect(status().isOk());
		
	}

}
