package com.Attornatus.Unitario;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.Date;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;
import com.Attornatus.Controller.PessoaController;
import com.Attornatus.Model.Pessoa;
import com.Attornatus.Repository.PessoaRepository;
import com.fasterxml.jackson.databind.ObjectMapper;


@WebMvcTest(controllers = PessoaController.class)
class PessoaControllerTeste {
	
	@Autowired
	private PessoaController pessoaController;
	
	@Autowired
	private MockMvc mockMvc;
	
	@Autowired
	private ObjectMapper objectMapper;
	
	@MockBean
	private PessoaRepository pessoaRepository;
	
	@Captor
	private ArgumentCaptor<Pessoa> pessoaCaptor;
	
	@Test
	void Listar() throws Exception {
		
		Date data_nascimento = Timestamp.valueOf("1910-05-14 00:00:00");
		Pessoa pessoa = new Pessoa(1, "Bruno", data_nascimento);
		
		Date data_nascimento2 = Timestamp.valueOf("2010-07-12 00:00:00"); 		
		Pessoa pessoa2 = new Pessoa(2, "Maria", data_nascimento2);

		ArrayList<Pessoa> listapessoa = new ArrayList<Pessoa>();
		listapessoa.add(pessoa);
		listapessoa.add(pessoa2);
		
		Mockito.when(pessoaRepository.findAll()).thenReturn(listapessoa);
		
		ArrayList<Pessoa> listaresultado = new ArrayList<Pessoa>();
		listaresultado.add(pessoa);
		listaresultado.add(pessoa2);
		
		System.out.println(objectMapper.writeValueAsString(listapessoa));
		mockMvc.perform(get("/pessoa"))
		.andExpect(status().isOk())
		.andExpect(content().json(objectMapper.writeValueAsString(listaresultado)));
		//assertEquals(listapessoa ,pessoaController.Listar());
		
	}
	
	@Test
	void Consulta() throws Exception {
		
		Date data_nascimento = Timestamp.valueOf("1910-05-14 00:00:00");
		Pessoa pessoa = new Pessoa(1, "Bruno", data_nascimento);
		
		Date data_nascimento2 = Timestamp.valueOf("2010-07-12 00:00:00"); 		
		Pessoa pessoa2 = new Pessoa(2, "Maria", data_nascimento2);

		Mockito.when((pessoaRepository.findById(1))).thenReturn(java.util.Optional.of(pessoa));
		
		Date data_nascimento_resultado = Timestamp.valueOf("1910-05-14 00:00:00");
		
		Pessoa resultado = new Pessoa();
		resultado.setId(1);
		resultado.setNome("Bruno");
		resultado.setData_nascimento(data_nascimento_resultado);	
		
		mockMvc.perform(get("/pessoa/{id}", 1))
				.andExpect(status().isOk())
				.andExpect(content().json(objectMapper.writeValueAsString(resultado)));
		
		//assertEquals(pessoa,pessoaController.Consulta(1));
	}
	
	
	@Test
	void Editar() throws Exception {
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		Date data_nascimento = Timestamp.valueOf("1910-05-14 00:00:00");
		Pessoa pessoa = new Pessoa(1, "Bruno", data_nascimento);
		
		Date data_nascimento2 = Timestamp.valueOf("2010-07-12 00:00:00"); 		
		Pessoa pessoa2 = new Pessoa(2, "Maria", data_nascimento2);
		
		Mockito.when(pessoaRepository.findById(1)).thenReturn(java.util.Optional.of(pessoa));
		
		data_nascimento = Timestamp.valueOf("1980-08-20 00:00:00");
		
		pessoa.setNome("Joel");
		pessoa.setData_nascimento(data_nascimento);
		
		Date data_nascimento_resultado = formatter.parse("1980-08-20");
		
		Pessoa resultado = new Pessoa();
		resultado.setId(1);
		resultado.setNome("Joel");
		resultado.setData_nascimento(data_nascimento_resultado);
		
		mockMvc.perform(post("/pessoa/{id}", 1)
					.contentType("application/json")
					.content(objectMapper.writeValueAsString(pessoa)))
					.andExpect(status().isOk());
		
		Mockito.verify(pessoaRepository).save(pessoaCaptor.capture());
		Pessoa pessoaEditada = pessoaCaptor.getValue();
		
		assertEquals(resultado, pessoaEditada);
		
		
	}
	
	@Test
	void Criar() throws Exception {
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		Date data_nascimento = formatter.parse("1910-05-14");
		Pessoa pessoa = new Pessoa(1, "Bruno", data_nascimento);
		
		Mockito.when(pessoaRepository.save(pessoa)).thenReturn(pessoa);
		
		 Pessoa resultado = new Pessoa();
		 resultado.setId(1);
		 resultado.setNome("Bruno");
		 resultado.setData_nascimento(data_nascimento);
		 
		 mockMvc.perform(post("/pessoa")
		.contentType("application/json")
		.content(objectMapper.writeValueAsString(pessoa)))
		.andExpect(status().isOk());
		 
		 Mockito.verify(pessoaRepository).save(pessoaCaptor.capture());
		 Pessoa pessoaSalva = pessoaCaptor.getValue();
		 
		 assertEquals(resultado, pessoaSalva);
		 
	}

}
